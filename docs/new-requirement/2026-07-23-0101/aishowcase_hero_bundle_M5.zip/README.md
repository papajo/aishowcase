
aishowcase.qzz.io Hero Generator Bundle for M5 16GB

WHAT'S INSIDE:
- aishowcase_web_ui.py - Web UI (recommended for M5) -> http://localhost:7860
- aishowcase_hero_local_m5.py - CLI local version
- aishowcase_hero_generator.py - API version (Replicate/Together)
- requirements_*.txt - dependencies
- example hero image

QUICK START (M5 Mac):
  python3 -m venv venv
  source venv/bin/activate
  pip install -r requirements_webui.txt
  python aishowcase_web_ui.py

Then open http://localhost:7860

For 10-20 images/day:
- Use SDXL Turbo mode (10 sec, <8GB RAM)
- All outputs are 1920x1280 WebP, warm terracotta/brown/amber palette
- Batch mode: paste titles, auto-saves to ./heroes/

API version (if you prefer cloud):
  export REPLICATE_API_TOKEN="r8_..."
  pip install -r requirements.txt
  python aishowcase_hero_generator.py --title "Your-Title-Here"

Palette: #C25E3E terracotta, #8B5A3C warm brown, #D4A056 golden amber, #FFF8F0 cream, #3E2723 chocolate
Style: Epic brain-over-city, no big text, cinematic hero

Created for aishowcase.qzz.io
